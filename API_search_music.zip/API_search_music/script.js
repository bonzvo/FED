document.getElementById("searchInput").addEventListener("input", function () {
  const query = this.value.trim();
  const resultsContainer = document.getElementById("results");
  const loader = document.getElementById("loader");

  if (!query) {
    resultsContainer.innerHTML = "<li>Unesite termin za pretragu...</li>";
    return;
  }

  loader.style.display = "block";

  fetch(
    `https://itunes.apple.com/search?term=${encodeURIComponent(
      query
    )}&entity=song`
  )
    .then((response) => response.json())
    .then((data) => {
      loader.style.display = "none";
      resultsContainer.innerHTML = "";
      //console.log(data);

      if (data.results.length === 0) {
        resultsContainer.innerHTML = "<li>Nema rezultata za prikazivanje.</li>";
      } else {
        data.results.forEach((song) => {
          const li = document.createElement("li");
          li.textContent = `${song.trackName} by ${song.artistName}`;
          resultsContainer.appendChild(li);
        });
      }
    })
    .catch((error) => {
      loader.style.display = "none";
      resultsContainer.innerHTML =
        "<li>Došlo je do greške prilikom pretrage.</li>";
      console.error("Error fetching data:", error);
    });
});


